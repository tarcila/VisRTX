# Handoff: ANARI devices disturb frame accumulation on unrelated commits (VisRTX, OSPRay, Barney, Visionaray)

## Where this came from

In Vela (`~/Code/ANARI/Vela/dont-map-depth-buffer`, jj workspace), picking was
being moved off the display frame onto a separate, temporary `ANARIFrame` that
shares the display's camera, renderer and world. The goal was for a pick not to
disturb the display frame's accumulation. On helide that works. On VisRTX the
display frame's accumulation restarts whenever the pick frame is committed.

The same thing happens without a second frame. **Committing any ANARI object
restarts accumulation on every accumulating frame of the device.** That
includes an unrelated camera that no frame references. Rendering a
pre-committed second frame does not restart it.

Vela context (read only if needed):
- Image Pipeline refactor spec: `~/Code/ANARI/Vela/dont-map-depth-buffer/.scratch/image-pipeline-cleanup/spec.md`
- ADR: `~/Code/ANARI/Vela/dont-map-depth-buffer/docs/adr/0028-give-image-pipelines-a-single-source-and-pick-outside-them.md`
- Uncommitted working-copy change that surfaced this:
  `AnariSceneRenderPass::renderPickSample` in
  `src/vsr/rendering/pipeline/passes/AnariSceneRenderPass.cpp`. It creates,
  commits, renders and releases a pick frame per pick.

## Standalone repro (no Vela dependency)

The repro is in `/tmp/visrtx-multiframe/`:
- `repro.cpp`: one C++17 file using only the ANARI-SDK C++ API. The scene is
  2000 matte spheres, a directional light and ambient light, in an 800×600
  frame. Frame A accumulates 8 samples. After sample 4 the chosen mode does its
  extra work, and frame A's color is written to `<mode>.ppm`. Set `TRACE=1` to
  also dump `<mode>_sK.ppm` after every sample.
- `run.sh`: builds against `$ANARI_SDK` and runs every mode for one library.
  It prints the difference between each mode's output and the undisturbed
  reference (`none`).
- `compare.py`: computes the mean and max absolute difference, and the count of
  differing bytes, between two PPMs.

```sh
ANARI_SDK=<anari-sdk prefix> /tmp/visrtx-multiframe/run.sh visrtx
ANARI_SDK=<anari-sdk prefix> /tmp/visrtx-multiframe/run.sh helide   # control
```

The modes, grouped by result:
- **Identical to the reference on both devices** (the expected result):
  - `create-only`: frame B is created and its parameters are set, but it is
    never committed.
  - `precommit`: frame B is committed before sample 1 and rendered once after
    sample 4.
  - `restart4`: frame A's own camera is re-committed with an unchanged value.
    This matches the reference, so an unchanged re-commit does not reset
    accumulation.
- **Different on VisRTX** (all byte-identical to each other):
  - `commit`: frame B is committed with the shared camera, renderer and world.
  - `render`: as `commit`, then frame B is rendered once.
  - `commit-own`: frame B has its own camera, renderer and empty world.
  - `commit-world`: frame B shares only the world.
  - `commit-bare`: frame B has no camera, renderer or world.
  - `commit-cam`: no frame B at all. A new camera is committed that nothing
    references.
- **The comparison point for a restart**:
  - `n5`: frame A rendered with 5 samples in total. In the `commit-*` modes,
    frame A gets 4 samples after the restart, and the first sample after any
    restart comes out identical to the second (see the trace below). A
    restarted run's final image is therefore expected to equal `n5`.

## Results (this machine)

Hardware and versions:
- GPU: NVIDIA RTX 5880 Ada Generation, driver 615.71.09.
- VisRTX: `/nix/store/mszk4cc9dqy6kkvyzc624hlpmkv165pg-visrtx-tsd_removed-unstable-2026-09-16`
  (from the Vela flake).
- ANARI-SDK: `/nix/store/kyhxqhmmzjky7kv0wk3xl44ibn8xzilb-anari-sdk-0.16.0-unstable-2026-09-17`.
- helide comes from the same SDK.

Every row is the difference against `none` (8 undisturbed samples, 800×600×3
bytes):

| mode | VisRTX | helide |
|---|---|---|
| none (rerun) | 0 | 0 |
| create-only | 0 | 0 |
| precommit | 0 | 0 |
| restart4 | 0 | 0 |
| commit, render, commit-own, commit-world, commit-bare, commit-cam | mean 2.13, max 104, 357685 bytes differ; **byte-identical to `n5`** | 0 |

Per-sample trace (`TRACE=1`) on VisRTX. The table gives the MD5 of frame A's
color after each sample. Identical hashes mark samples whose images were
identical.

| sample | none | commit-cam |
|---|---|---|
| 1 | efee46c9 | efee46c9 |
| 2 | efee46c9 | efee46c9 |
| 3 | 8e83cb01 | 8e83cb01 |
| 4 | 2601ae2e | 2601ae2e |
| 5 | b4f8edc2 | **efee46c9** |
| 6 | 120febd0 | 8e83cb01 |
| 7 | 56f5cb86 | 2601ae2e |
| 8 | ac9dae48 | b4f8edc2 |

After an unrelated commit, frame A restarts from sample 1. The samples it
renders after the restart are bit-identical to its first samples.

## Other devices (same repro, same machine, Vela flake builds)

The user decided to keep Vela's per-pick frame and have the devices fixed. So
this is no longer VisRTX-only: I ran every mode on each device available here.
Each cell is the difference against that device's undisturbed `none`
reference. `0` means identical, i.e. accumulation was not disturbed. Reruns of
`none` were bit-identical on every device.

| mode | VisRTX | OSPRay | Barney | Visionaray | helide |
|---|---|---|---|---|---|
| create-only (never committed) | 0 | 0 | 0 | 0 | 0 |
| commit-cam (unrelated camera, no frame B) | **2.13** | **1.62** | 0 | 0 | 0 |
| commit-bare (frame B, nothing shared) | **2.13** | **1.62** | **0.63** | **2.36** | 0 |
| commit (frame B shares cam/renderer/world) | **2.13** | **1.62** | **0.63** | **2.36** | 0 |
| render (commit + render B) | **2.13** | **1.62** | **0.63** | **2.36** | 0 |
| precommit (B committed up front, rendered after sample 4) | 0 | 0 | ~0 † | **2.14** | 0 |
| restart4 (frame A's camera re-committed, unchanged) | 0 | 0 | 0 | 0 | 0 |

Values are mean absolute differences in 8-bit units.
† Barney showed sporadic max-1 differences (about 2k of 1.44M bytes) in
`precommit` on one run and in `commit-cam` on another. I read that as device
nondeterminism at the ±1 level, not as this effect.

How the devices differ:
- **VisRTX and OSPRay:** any object commit disturbs every accumulating frame,
  even a camera nothing references. On VisRTX the result is byte-identical to
  a clean restart (`n5`). On OSPRay the image is disturbed but does not match
  `n5`, so it is not a plain restart.
- **Barney and Visionaray:** committing a *frame* disturbs other accumulating
  frames, while other objects (an unrelated camera) do not. The disturbed
  image does not match `n5` on Barney. On Visionaray it does.
- **Visionaray only:** *rendering* a second frame also disturbs frame A, even
  when that frame was committed before accumulation started (`precommit`). So
  on Visionaray even a cached pick frame would not avoid it.
- **helide:** never disturbed. It is the reference behaviour Vela expects.

What Vela does now: one temporary frame per pick, sharing the display's
camera, renderer and world, created, committed, rendered and released within
the pick. On every device above except helide, that disturbs the display's
accumulation until the device is fixed.

## Hypothesis

VisRTX probably decides whether to reset a frame's accumulation by comparing
against a **device-wide** "last commit/finalize" timestamp. It should instead
use the modification time of the objects that frame depends on (camera,
renderer, world and their contents, plus the frame's own parameters).
helium's `DeferredCommitBuffer` exposes
`lastObjectCommit()` / `lastObjectFinalization()`. A frame that compares
against those device-global stamps would restart on every commit anywhere.
Look at VisRTX's `Frame` code: the renderFrame or accumulation-reset logic,
and how it decides "scene changed since the last render". Check whether it
consults the device's commit buffer timestamps rather than per-object
`lastUpdated()`/`lastCommitted()` stamps.

The observation that `restart4` does **not** restart matters here. A re-commit
of the frame's own camera with an unchanged value does not reset, but a commit
of an unrelated new camera does. Two explanations fit:
- the camera's commit is recognised as a no-op change;
- the reset is triggered by object creation and finalization, not by
  parameter commits on existing objects.

Worth testing both.

## Why it matters

- **Vela picking:** any feature that commits objects while an interactive frame
  accumulates silently restarts the display. That includes a pick frame, a
  thumbnail or preview frame, or creating objects that aren't in the world yet.
- **ANARI conformance:** the frame accumulation semantics in the ANARI spec tie
  a reset to changes in objects the frame (transitively) references. A commit
  to an unreferenced object should not reset it. Confirm the exact spec wording
  before filing.

## Suggested next steps

1. Start with VisRTX, the primary target. Get a VisRTX checkout. None exists on this machine yet: `ls ~/Code/ANARI`
   shows only `Vela`. The Vela flake pins the source used here
   (`tsd_removed-unstable-2026-09-16`).
2. Run `run.sh` against that checkout's build to confirm it reproduces on the
   current VisRTX main.
3. Find the reset trigger in VisRTX's Frame accumulation logic, then fix it or
   write the issue with the repro attached. OSPRay likely has the same kind of
   device-global trigger. For Barney and Visionaray, look at what a frame
   commit (and, on Visionaray, a frame render) touches that is shared between
   frames: a per-device accumulation buffer, sample counter or RNG seed.
4. When writing it up, include the table above and the helide control.
   Don't publish issues or PRs unless the user explicitly asks; notes stay
   local.

Vela does not wait on this. The user chose to keep the per-pick frame
(correct per ANARI semantics) and fix the devices. Report per device, each
with its own mechanism from the table above.

## Suggested skills

- `diagnosing-bugs`: this is a reproduce → minimise → hypothesise → verify
  loop. The repro and minimisation are done, and the hypothesis still needs
  checking against VisRTX source.
- `research`: only if you need ANARI spec wording on frame accumulation
  semantics. Use primary sources, meaning the ANARI spec at
  registry.khronos.org.
- `tdd`: if a fix goes into VisRTX, turn `repro.cpp` into a regression test in
  its test suite.
