#!/usr/bin/env bash
# Build and run the repro against one ANARI library, printing diffs vs the
# undisturbed 8-sample reference. Usage: ANARI_SDK=<prefix> ./run.sh [library]
set -euo pipefail
cd "$(dirname "$0")"
lib=${1:-visrtx}
: "${ANARI_SDK:?set ANARI_SDK to the ANARI-SDK install prefix (include/ lib/)}"
g++ -std=c++17 -O1 repro.cpp -I"$ANARI_SDK/include" -L"$ANARI_SDK/lib" \
  -Wl,-rpath,"$ANARI_SDK/lib" -lanari -o repro
mkdir -p "$lib" && cd "$lib"
export ANARI_LIBRARY=$lib
modes="none create-only commit-cam commit-bare commit-own commit-world commit render precommit restart4 n5"
for m in $modes; do ../repro "$m" >/dev/null 2>&1; done
for m in $modes; do python3 ../compare.py none.ppm "$m.ppm"; done
