# Mean/max absolute difference between two PPMs (P6, 8-bit).
import sys
def load(p):
    b = open(p, 'rb').read()
    parts = b.split(b'\n', 3)
    return parts[3]
a, b = load(sys.argv[1]), load(sys.argv[2])
d = [abs(x - y) for x, y in zip(a, b)]
print(f"{sys.argv[2]:>14} vs {sys.argv[1]}: mean {sum(d)/len(d):.4f}  max {max(d)}  differing {sum(1 for v in d if v)}/{len(d)}")
