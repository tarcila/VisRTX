// Standalone repro: committing a second ANARI frame that shares camera,
// renderer and world with an accumulating frame perturbs the first frame's
// accumulated image on VisRTX (not on helide).
//
// Modes (argv[1]):
//   none         8 samples on frame A only (reference)
//   commit       commit frame B (shared objects) after sample 4, never render it
//   render       same as commit, then render + wait frame B once
//   precommit    commit frame B before sample 1, render + wait it after sample 4
//   commit-own   commit frame B after sample 4 with its own camera, renderer
//                and world (nothing shared), never render it
//   commit-world commit frame B after sample 4 sharing only the world
//   commit-bare  commit frame B after sample 4 with no camera/renderer/world
//   create-only  create frame B after sample 4, set parameters, never commit
//   commit-cam   commit a new, unattached camera after sample 4 (no frame B)
//   restart4     frame A's own "camera" re-committed after sample 4 (a
//                documented accumulation reset) -- what a restart looks like
//   n1..n8       reference: frame A rendered N samples only (no other work)
// Output: <mode>.ppm (frame A color after 8 samples)
#include <anari/anari_cpp.hpp>
#include <anari/anari_cpp/ext/std.h>
#include <cstdio>
#include <cstring>
#include <random>
#include <string>
#include <vector>

using float3 = std::array<float, 3>;
using uint2 = std::array<uint32_t, 2>;

static void status(const void *, ANARIDevice, ANARIObject, ANARIDataType,
    ANARIStatusSeverity sev, ANARIStatusCode, const char *msg)
{
  if (sev <= ANARI_SEVERITY_WARNING)
    fprintf(stderr, "[ANARI] %s\n", msg);
}

static void writePPM(anari::Device d, anari::Frame f, const std::string &name)
{
  auto fb = anari::map<uint32_t>(d, f, "channel.color");
  FILE *fp = fopen(name.c_str(), "wb");
  fprintf(fp, "P6\n%u %u\n255\n", fb.width, fb.height);
  for (uint32_t i = 0; i < fb.width * fb.height; i++) {
    const uint32_t p = fb.data[i];
    const unsigned char rgb[3] = {uint8_t(p), uint8_t(p >> 8), uint8_t(p >> 16)};
    fwrite(rgb, 1, 3, fp);
  }
  fclose(fp);
  anari::unmap(d, f, "channel.color");
}

static anari::Frame makeFrame(anari::Device d, uint2 size, anari::Camera c,
    anari::Renderer r, anari::World w, bool accumulate)
{
  auto f = anari::newObject<anari::Frame>(d);
  anari::setParameter(d, f, "size", size);
  anari::setParameter(d, f, "channel.color", ANARI_UFIXED8_RGBA_SRGB);
  anari::setParameter(d, f, "channel.depth", ANARI_FLOAT32);
  anari::setParameter(d, f, "camera", c);
  anari::setParameter(d, f, "renderer", r);
  anari::setParameter(d, f, "world", w);
  anari::setParameter(d, f, "accumulation", accumulate);
  return f;
}

int main(int argc, char **argv)
{
  const std::string mode = argc > 1 ? argv[1] : "none";
  const char *libName = getenv("ANARI_LIBRARY") ? getenv("ANARI_LIBRARY") : "visrtx";
  auto lib = anari::loadLibrary(libName, status);
  auto d = anari::newDevice(lib, "default");

  // Scene: 2000 random spheres + a directional light.
  std::mt19937 rng(42);
  std::uniform_real_distribution<float> u(-1.f, 1.f);
  std::vector<float3> pos(2000);
  for (auto &p : pos)
    p = {u(rng), u(rng), u(rng)};
  auto geom = anari::newObject<anari::Geometry>(d, "sphere");
  anari::setParameterArray1D(d, geom, "vertex.position", pos.data(), pos.size());
  anari::setParameter(d, geom, "radius", 0.03f);
  anari::commitParameters(d, geom);
  auto mat = anari::newObject<anari::Material>(d, "matte");
  anari::setParameter(d, mat, "color", float3{0.8f, 0.4f, 0.1f});
  anari::commitParameters(d, mat);
  auto surf = anari::newObject<anari::Surface>(d);
  anari::setParameter(d, surf, "geometry", geom);
  anari::setParameter(d, surf, "material", mat);
  anari::commitParameters(d, surf);
  auto light = anari::newObject<anari::Light>(d, "directional");
  anari::setParameter(d, light, "direction", float3{-1.f, -1.f, -1.f});
  anari::commitParameters(d, light);
  auto world = anari::newObject<anari::World>(d);
  anari::setParameterArray1D(d, world, "surface", &surf, 1);
  anari::setParameterArray1D(d, world, "light", &light, 1);
  anari::commitParameters(d, world);

  const uint2 size = {800, 600};
  auto cam = anari::newObject<anari::Camera>(d, "perspective");
  anari::setParameter(d, cam, "position", float3{0.f, 0.f, 3.f});
  anari::setParameter(d, cam, "direction", float3{0.f, 0.f, -1.f});
  anari::setParameter(d, cam, "up", float3{0.f, 1.f, 0.f});
  anari::setParameter(d, cam, "aspect", size[0] / float(size[1]));
  anari::commitParameters(d, cam);
  auto ren = anari::newObject<anari::Renderer>(d, "default");
  anari::setParameter(d, ren, "ambientRadiance", 0.3f);
  anari::commitParameters(d, ren);

  auto a = makeFrame(d, size, cam, ren, world, true);
  anari::commitParameters(d, a);

  anari::Frame b = nullptr;
  if (mode == "precommit") {
    b = makeFrame(d, size, cam, ren, world, false);
    anari::commitParameters(d, b);
  }

  int samples = 8;
  if (mode.size() == 2 && mode[0] == 'n')
    samples = mode[1] - '0';
  for (int i = 0; i < samples; i++) {
    anari::render(d, a);
    anari::wait(d, a);
    if (getenv("TRACE"))
      writePPM(d, a, mode + "_s" + std::to_string(i + 1) + ".ppm");
    if (i == 3) {
      if (mode == "commit" || mode == "render") {
        b = makeFrame(d, size, cam, ren, world, false);
        anari::commitParameters(d, b);
      }
      if (mode == "commit-own" || mode == "commit-world") {
        auto c2 = anari::newObject<anari::Camera>(d, "perspective");
        anari::setParameter(d, c2, "position", float3{0.f, 0.f, 3.f});
        anari::setParameter(d, c2, "direction", float3{0.f, 0.f, -1.f});
        anari::setParameter(d, c2, "aspect", size[0] / float(size[1]));
        anari::commitParameters(d, c2);
        auto r2 = anari::newObject<anari::Renderer>(d, "default");
        anari::commitParameters(d, r2);
        anari::World w2 = world;
        if (mode == "commit-own") {
          w2 = anari::newObject<anari::World>(d);
          anari::commitParameters(d, w2);
        } else
          anari::retain(d, w2);
        b = makeFrame(d, size, c2, r2, w2, false);
        anari::commitParameters(d, b);
        anari::release(d, c2);
        anari::release(d, r2);
        anari::release(d, w2);
      }
      if (mode == "restart4") {
        anari::setParameter(d, cam, "position", float3{0.f, 0.f, 3.f});
        anari::commitParameters(d, cam);
      }
      if (mode == "create-only") {
        b = makeFrame(d, size, cam, ren, world, false);
      }
      if (mode == "commit-cam") {
        auto c3 = anari::newObject<anari::Camera>(d, "perspective");
        anari::commitParameters(d, c3);
        anari::release(d, c3);
      }
      if (mode == "commit-bare") {
        b = anari::newObject<anari::Frame>(d);
        anari::setParameter(d, b, "size", size);
        anari::setParameter(d, b, "channel.color", ANARI_UFIXED8_RGBA_SRGB);
        anari::commitParameters(d, b);
      }
      if (b && (mode == "render" || mode == "precommit")) {
        anari::render(d, b);
        anari::wait(d, b);
      }
    }
  }

  writePPM(d, a, mode + ".ppm");

  if (b)
    anari::release(d, b);
  anari::release(d, a);
  anari::release(d, ren);
  anari::release(d, cam);
  anari::release(d, world);
  anari::release(d, light);
  anari::release(d, surf);
  anari::release(d, mat);
  anari::release(d, geom);
  anari::release(d, d);
  anari::unloadLibrary(lib);
  return 0;
}
